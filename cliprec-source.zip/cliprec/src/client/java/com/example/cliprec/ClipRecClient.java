package com.example.cliprec;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** F9 = start / stop recording. Clips (MP4 via ffmpeg) go to <instance>/clips */
public class ClipRecClient implements ClientModInitializer {
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cliprec.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F9,
                KeyBinding.Category.create(Identifier.of("cliprec", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                if (Recorder.isRecording()) {
                    Recorder.stop();
                    msg(client, "Recording saved to clips folder");
                } else {
                    Recorder.start();
                    msg(client, "Recording started (F9 to stop)");
                }
            }
            String warn = Recorder.consumeWarning();
            if (warn != null) msg(client, warn);
            if (Recorder.consumeAutoStopped()) msg(client, "Recording stopped (file size limit) - saved");
        });
    }

    private static void msg(net.minecraft.client.MinecraftClient c, String s) {
        if (c.player != null) c.player.sendMessage(Text.literal(s), true);
    }
}
