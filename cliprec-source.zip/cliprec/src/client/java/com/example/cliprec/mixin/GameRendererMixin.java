package com.example.cliprec.mixin;

import com.example.cliprec.Recorder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void cliprec$afterRender(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        Recorder.onFrame();
    }
}
