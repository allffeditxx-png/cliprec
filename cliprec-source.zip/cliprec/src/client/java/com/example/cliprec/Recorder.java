package com.example.cliprec;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Records the game frame. Pipes raw frames to ffmpeg -> MP4.
 * If ffmpeg can't be started, falls back to a pure-Java AVI (MJPEG).
 *
 * Optional config: <instance>/config/cliprec.properties
 *   ffmpeg=C:/tools/ffmpeg/bin/ffmpeg.exe   (default: ffmpeg from PATH)
 *   encoder=libx264                         (e.g. h264_nvenc, h264_amf, h264_qsv)
 *   fps=15            (light defaults for phones; raise for smoother video)
 *   height=480
 *   quality=0.5       (AVI fallback only, 0.1-1.0)
 *   crf=23
 *   threads=2                               (lower = less CPU taken from the game)
 */
public final class Recorder {
    private static int FPS = 15;               // light defaults for phones
    private static int MAX_HEIGHT = 480;
    private static String FFMPEG = "ffmpeg";
    private static String ENCODER = "libx264";
    private static String CRF = "23";
    private static String THREADS = "2";           // CPU threads ffmpeg may use (libx264 only)
    private static float JPEG_QUALITY = 0.5f;  // AVI fallback only
    static final long AVI_MAX_BYTES = 1_500_000_000L;

    private record Frame(NativeImage img, long ns) {}

    private static volatile boolean recording;
    private static volatile boolean autoStopped;
    private static volatile String warning;
    private static long startNs, lastCaptureNs;
    private static ArrayBlockingQueue<Frame> queue;
    private static Thread worker;
    private static final AtomicBoolean pending = new AtomicBoolean(false); // only one GPU readback at a time

    public static boolean isRecording() { return recording; }
    public static boolean consumeAutoStopped() { boolean b = autoStopped; autoStopped = false; return b; }
    public static String consumeWarning() { String w = warning; warning = null; return w; }

    private static void loadConfig() {
        try {
            Path cfg = FabricLoader.getInstance().getConfigDir().resolve("cliprec.properties");
            if (!Files.exists(cfg)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(cfg)) { p.load(in); }
            FFMPEG = p.getProperty("ffmpeg", FFMPEG).trim();
            ENCODER = p.getProperty("encoder", ENCODER).trim();
            CRF = p.getProperty("crf", CRF).trim();
            THREADS = p.getProperty("threads", THREADS).trim();
            JPEG_QUALITY = Float.parseFloat(p.getProperty("quality", String.valueOf(JPEG_QUALITY)).trim());
            FPS = Integer.parseInt(p.getProperty("fps", String.valueOf(FPS)).trim());
            MAX_HEIGHT = Integer.parseInt(p.getProperty("height", String.valueOf(MAX_HEIGHT)).trim());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static synchronized void start() {
        if (recording) return;
        loadConfig();
        queue = new ArrayBlockingQueue<>(6);
        startNs = System.nanoTime();
        lastCaptureNs = 0;
        pending.set(false);
        recording = true;
        Thread t = new Thread(Recorder::encodeLoop, "ClipRec-Encoder");
        t.setPriority(Thread.MIN_PRIORITY);
        worker = t;
        t.start();
    }

    public static synchronized void stop() {
        if (!recording && worker == null) return;
        recording = false;
        Thread t = worker;
        if (t != null) {
            try { t.join(30000); } catch (InterruptedException ignored) {}
        }
        worker = null;
    }

    /** Called at the end of every rendered frame (from GameRendererMixin). */
    public static void onFrame() {
        if (!recording) return;
        long now = System.nanoTime();
        if (now - lastCaptureNs < 1_000_000_000L / FPS) return;
        if (!pending.compareAndSet(false, true)) return; // previous readback not finished yet - skip
        lastCaptureNs = now;
        final long ts = now;
        final ArrayBlockingQueue<Frame> q = queue;
        try {
            ScreenshotRecorder.takeScreenshot(MinecraftClient.getInstance().getFramebuffer(), image -> {
                try {
                    if (q == null || !q.offer(new Frame(image, ts))) image.close(); // drop frame if encoder is behind
                } finally {
                    pending.set(false);
                }
            });
        } catch (Throwable t) {
            pending.set(false);
        }
    }

    private static Process startFfmpeg(Path out, int w, int h) {
        try {
            List<String> cmd = new ArrayList<>(List.of(
                    FFMPEG, "-y", "-loglevel", "error",
                    "-f", "rawvideo", "-pix_fmt", "rgb24",
                    "-s", w + "x" + h, "-r", String.valueOf(FPS), "-i", "-",
                    "-c:v", ENCODER));
            if (ENCODER.equals("libx264")) {
                cmd.addAll(List.of("-preset", "ultrafast", "-crf", CRF, "-threads", THREADS));
            }
            cmd.addAll(List.of("-pix_fmt", "yuv420p", "-movflags", "+faststart", out.toString()));
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
            pb.redirectError(ProcessBuilder.Redirect.DISCARD);
            return pb.start();
        } catch (Exception e) {
            return null;
        }
    }

    private static void encodeLoop() {
        AviWriter avi = null;
        Process proc = null;
        OutputStream pipe = null;
        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve("clips");
            Files.createDirectories(dir);
            String base = "clip-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));

            ImageWriter jw = null;
            ImageWriteParam param = null;
            BufferedImage bi = null;
            int[] px = null;
            byte[] raw = null;
            int outW = 0, outH = 0;
            long written = 0;

            while (recording || !queue.isEmpty()) {
                Frame f = queue.poll(100, TimeUnit.MILLISECONDS);
                if (f == null) continue;
                try {
                    NativeImage img = f.img();
                    int w = img.getWidth(), h = img.getHeight();

                    if (proc == null && avi == null) { // first frame: open the output
                        outH = Math.min(h, MAX_HEIGHT) & ~1;
                        outW = ((int) (w * (double) outH / h)) & ~1;
                        proc = startFfmpeg(dir.resolve(base + ".mp4"), outW, outH);
                        if (proc != null) {
                            pipe = new BufferedOutputStream(proc.getOutputStream(), 1 << 20);
                            raw = new byte[outW * outH * 3];
                        } else {
                            warning = "ffmpeg not found - saving AVI instead (set ffmpeg path in config/cliprec.properties)";
                            jw = ImageIO.getImageWritersByFormatName("jpeg").next();
                            param = jw.getDefaultWriteParam();
                            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                            param.setCompressionQuality(JPEG_QUALITY);
                            bi = new BufferedImage(outW, outH, BufferedImage.TYPE_INT_RGB);
                            px = ((DataBufferInt) bi.getRaster().getDataBuffer()).getData();
                            avi = new AviWriter(dir.resolve(base + ".avi"), outW, outH, FPS);
                        }
                    }

                    // repeat the frame if capture fell behind, to keep real-time speed
                    long target = (f.ns() - startNs) * FPS / 1_000_000_000L;
                    int repeats = (int) Math.max(1, Math.min(target - written + 1, FPS * 2L));

                    if (proc != null) {
                        int i = 0;
                        for (int y = 0; y < outH; y++) {
                            int sy = (int) ((long) y * h / outH);
                            for (int x = 0; x < outW; x++) {
                                int c = img.getColorArgb((int) ((long) x * w / outW), sy);
                                raw[i++] = (byte) (c >> 16);
                                raw[i++] = (byte) (c >> 8);
                                raw[i++] = (byte) c;
                            }
                        }
                        for (int r = 0; r < repeats; r++) { pipe.write(raw); written++; }
                    } else {
                        for (int y = 0; y < outH; y++) {
                            int sy = (int) ((long) y * h / outH);
                            for (int x = 0; x < outW; x++) {
                                px[y * outW + x] = img.getColorArgb((int) ((long) x * w / outW), sy) & 0xFFFFFF;
                            }
                        }
                        ByteArrayOutputStream bos = new ByteArrayOutputStream(64 * 1024);
                        try (MemoryCacheImageOutputStream ios = new MemoryCacheImageOutputStream(bos)) {
                            jw.setOutput(ios);
                            jw.write(null, new IIOImage(bi, null, null), param);
                        }
                        byte[] jpg = bos.toByteArray();
                        for (int r = 0; r < repeats; r++) { avi.addFrame(jpg); written++; }
                        if (avi.size() > AVI_MAX_BYTES) { autoStopped = true; recording = false; }
                    }
                } finally {
                    f.img().close();
                }
            }
            if (jw != null) jw.dispose();
        } catch (Throwable t) {
            t.printStackTrace();
            warning = "Recording error - see latest.log";
            recording = false;
        } finally {
            Frame f;
            while (queue != null && (f = queue.poll()) != null) f.img().close();
            try {
                if (pipe != null) { pipe.flush(); pipe.close(); }
                if (proc != null && !proc.waitFor(30, TimeUnit.SECONDS)) proc.destroy();
            } catch (Exception e) { e.printStackTrace(); }
            if (avi != null) { try { avi.close(); } catch (Exception e) { e.printStackTrace(); } }
        }
    }
}
