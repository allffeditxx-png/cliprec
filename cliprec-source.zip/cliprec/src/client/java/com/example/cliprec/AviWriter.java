package com.example.cliprec;

import java.io.Closeable;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Minimal MJPEG-in-AVI writer (pure Java, no ffmpeg needed). */
final class AviWriter implements Closeable {
    private final RandomAccessFile f;
    private final int w, h, fps;
    private final List<int[]> index = new ArrayList<>(); // {offsetFromMovi, size}
    private long moviBytes = 4; // 'movi' fourcc
    private int maxChunk = 0;

    AviWriter(Path p, int w, int h, int fps) throws IOException {
        this.w = w; this.h = h; this.fps = fps;
        f = new RandomAccessFile(p.toFile(), "rw");
        f.setLength(0);
        f.write(header());
    }

    long size() throws IOException { return f.getFilePointer(); }

    private static void fcc(ByteBuffer b, String s) { b.put(s.getBytes(java.nio.charset.StandardCharsets.US_ASCII)); }

    private byte[] header() {
        ByteBuffer b = ByteBuffer.allocate(224).order(ByteOrder.LITTLE_ENDIAN);
        fcc(b, "RIFF"); b.putInt(0); fcc(b, "AVI ");
        fcc(b, "LIST"); b.putInt(192); fcc(b, "hdrl");
        fcc(b, "avih"); b.putInt(56);
        b.putInt(1_000_000 / fps); b.putInt(0); b.putInt(0); b.putInt(0x10); // flags: has index
        b.putInt(0);            // totalFrames @48 (patched)
        b.putInt(0); b.putInt(1);
        b.putInt(0);            // suggested buffer @60 (patched)
        b.putInt(w); b.putInt(h); b.putInt(0); b.putInt(0); b.putInt(0); b.putInt(0);
        fcc(b, "LIST"); b.putInt(116); fcc(b, "strl");
        fcc(b, "strh"); b.putInt(56);
        fcc(b, "vids"); fcc(b, "MJPG");
        b.putInt(0); b.putInt(0); b.putInt(0);
        b.putInt(1); b.putInt(fps); b.putInt(0);
        b.putInt(0);            // length @140 (patched)
        b.putInt(0);            // suggested buffer @144 (patched)
        b.putInt(-1); b.putInt(0);
        b.putShort((short) 0); b.putShort((short) 0); b.putShort((short) w); b.putShort((short) h);
        fcc(b, "strf"); b.putInt(40);
        b.putInt(40); b.putInt(w); b.putInt(h);
        b.putShort((short) 1); b.putShort((short) 24);
        fcc(b, "MJPG");
        b.putInt(w * h * 3); b.putInt(0); b.putInt(0); b.putInt(0); b.putInt(0);
        fcc(b, "LIST"); b.putInt(0); fcc(b, "movi"); // movi size @216 (patched)
        return b.array();
    }

    void addFrame(byte[] jpg) throws IOException {
        long pos = f.getFilePointer();
        int pad = jpg.length & 1;
        ByteBuffer hd = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        fcc(hd, "00dc"); hd.putInt(jpg.length);
        f.write(hd.array());
        f.write(jpg);
        if (pad == 1) f.write(0);
        index.add(new int[]{(int) (pos - 220), jpg.length});
        moviBytes += 8 + jpg.length + pad;
        if (jpg.length > maxChunk) maxChunk = jpg.length;
    }

    private void patch(long at, int v) throws IOException {
        f.seek(at);
        f.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array());
    }

    @Override public void close() throws IOException {
        f.seek(f.length());
        ByteBuffer ix = ByteBuffer.allocate(8 + 16 * index.size()).order(ByteOrder.LITTLE_ENDIAN);
        fcc(ix, "idx1"); ix.putInt(16 * index.size());
        for (int[] e : index) { fcc(ix, "00dc"); ix.putInt(0x10); ix.putInt(e[0]); ix.putInt(e[1]); }
        f.write(ix.array());
        long len = f.length();
        patch(4, (int) (len - 8));
        patch(48, index.size());
        patch(60, maxChunk);
        patch(140, index.size());
        patch(144, maxChunk);
        patch(216, (int) moviBytes);
        f.close();
    }
}
